My Backgrounds for use in the  GBZ35 Theme on Raspberry Pi.

This is the newly completed set of backgrounds (if I misssed any feel free to let me know). its the 3rd rendition and corrects a cuple of small errors with picture placement (atari 800 for example) and one completely wrong image (wonderswan showed a crystal instead of the origial ws). I also added a couple of additional alternative images to (such as favourites) as they were more personal taste and didnt particularly go as well with the themes feel.

Each emulator has a picture of the machine it is emulating along with the date of that machines release shown in the corner. some folders also contain an additional/alternative background image (especially genesis/megadrive and snes/supernes type systems that went by different names in different countries). the image that will show by default where there are alternates is the image named 'background.png', if you want the alternate, just rename or delete the one you dont want and rename the one you want to show as 'background.png' (without the quotation marks).

It might be worth looking through all of them before transfer if the alternate options are important to you. though if you transfer all the files you can always do it later on the actual machine files.


Created for use on 640x480 screen devices like the piboy Dmg and specifically made for use on the gbz35 theme though it may suit others too. screens with a different aspect ratio/resolution  will stretch the images. 

I found a few systems were missing in my copy of gbz35 so I created and added the missing items to the set (MSX2 for example). it involved me adding a further folder (inc), a system title file and a theme xml to each folder of those new machines . If you want those new additions to work properly you need to copy the full contents of each applicable folder (background image, inc folder, theme xml) to your installed gbz35 theme.

Installation Instructions:-

Install GBZ35 Theme via ES themes on your device.

Replace the background images in your installed version of GBZ35 with the images from this sets folder either by doing them individually, or by just copying and replacing the full set as a whole (my preferred and far quicker/simpler option). pasting the full set will only replace the necessary files in your installed gbz35 folder and won't affect any other files in there.

The default installation location for emulation station themes is:-

 root/etc/emulationstation/themes 

thats it. 

Select gbz35 as your theme in emulation station menu and it will automatically show the new backgrounds.




Problems and issues.

no known issues with the actual additions. 

However, the process of adding them to the file system needs the following info.

Winscp doesn't always allow transfer/write access to your installed theme due to write permissions on the themes folder contents. in which case you will need to take control of those permissions to continue with file replacements. Google how to fix that problem. its not something I have had to do but I know others have done it. 

For those using Paragon softwares linux reader software, just copy and paste the files. But Note:- I have found that once every so often, the Paragon software will corrupt an sd card. For anyone using paragon for file transfers. Ideally back up your card first, get the transfer done and get out quickly. I no longer fully trust that software approach.

As always, big thanks to the creator of GBZ35. I tailored my files around that theme, as it best suits a small screen and the new images. 

solely for id purposes and to save confusion, I'll sign this as Dragonlord rather than Diablo as thats what my github links to.
  